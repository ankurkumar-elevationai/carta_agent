import os
import logging
from google.cloud import storage

log = logging.getLogger(__name__)

def upload_file(local_path: str, destination_blob_name: str) -> str:
    """
    Uploads a file to the Google Cloud Storage bucket.
    Requires GOOGLE_APPLICATION_CREDENTIALS or implicit credentials.
    GCS_BUCKET_NAME env var should be set.
    """
    bucket_name = os.environ.get("GCS_BUCKET_NAME")
    if not bucket_name:
        log.warning("GCS_BUCKET_NAME not set. Skipping GCS upload.")
        return f"file://{local_path}"

    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(local_path)
        log.info(f"File {local_path} uploaded to {destination_blob_name}.")
        
        # Depending on bucket permissions, generate a signed URL or public URL.
        # Here we return the direct gs:// URI or public URL.
        # In a real environment, you might want a Signed URL or just public URL if ACL allows.
        return f"gs://{bucket_name}/{destination_blob_name}"
    except Exception as e:
        log.error(f"Failed to upload to GCS: {e}")
        raise
