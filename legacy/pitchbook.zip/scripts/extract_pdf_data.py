"""
extract_pdf_data.py
-------------------
Production-grade PitchBook PDF extraction pipeline:

  PDF → Layout-aware extraction → Section chunking → Entity Boundary Detection
      → Table extraction → Typed micro-chunking (Parallel) → Grounding
      → LLM semantic parsing → Entity resolution → Canonical JSON

"""

import os
import re
import json
import argparse
import logging
import concurrent.futures
from pathlib import Path
from typing import Optional, Any, List, Dict

import pdfplumber
import fitz
from PIL import Image
import io
from pydantic import BaseModel, Field
from dotenv import load_dotenv

try:
    from gliner import GLiNER
except ImportError:
    GLiNER = None

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

PDF_DIR = "./output/pdfs"
DATA_DIR = "./output/data"
MICRO_CHUNK_SIZE_LIMIT = 8000
MAX_CONCURRENT_REQUESTS = 4

gliner_model = None
def get_gliner_model():
    global gliner_model
    if GLiNER and not gliner_model:
        log.info("Loading GLiNER model for Entity Boundary Detection...")
        gliner_model = GLiNER.from_pretrained("urchade/gliner_multi-v2.1")
    return gliner_model

# ══════════════════════════════════════════════════════════════════════════════
# Pydantic Schemas
# ══════════════════════════════════════════════════════════════════════════════

class ProvenanceMeta(BaseModel):
    pages: List[int] = Field(default_factory=list)
    sections: List[str] = Field(default_factory=list)

class CompanyOverview(BaseModel):
    name: Optional[str] = Field(None, description="Official company name")
    description: Optional[str] = Field(None, description="Full company description paragraph")
    primary_industry: Optional[str] = Field(None, description="Primary industry (e.g. 'FinTech', 'SaaS')")
    sub_industries: list[str] = Field(default_factory=list, description="Sub-industries and verticals")
    founded_year: Optional[str] = Field(None, description="Year founded (e.g. '2010')")
    hq_location: Optional[str] = Field(None, description="HQ city, state/country (e.g. 'San Francisco, CA')")
    website: Optional[str] = Field(None, description="Website URL")
    employee_count: Optional[str] = Field(None, description="Number of employees (e.g. '8,500')")
    status: Optional[str] = Field(None, description="Company status (e.g. 'Generating Revenue')")
    ownership_status: Optional[str] = Field(None, description="Ownership (e.g. 'Venture Capital-Backed')")
    financing_status: Optional[str] = Field(None, description="Financing status (e.g. 'Venture Capital-Backed')")
    legal_name: Optional[str] = Field(None, description="Legal entity name if different from trade name")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class Financials(BaseModel):
    total_raised: Optional[str] = Field(None, description="Total funding raised to date (e.g. '$8.73B')")
    last_known_valuation: Optional[str] = Field(None, description="Last known post-money valuation (e.g. '$159.00B')")
    valuation_date: Optional[str] = Field(None, description="Date of last known valuation")
    valuation_estimate: Optional[str] = Field(None, description="PitchBook valuation estimate if available")
    valuation_confidence: Optional[str] = Field(None, description="Confidence level (e.g. 'Very High Confidence')")
    valuation_step_up: Optional[str] = Field(None, description="Valuation step-up multiple (e.g. '0.46x')")
    revenue: Optional[str] = Field(None, description="Annual revenue if disclosed")
    revenue_year: Optional[str] = Field(None, description="Fiscal year for reported revenue")
    last_financing_type: Optional[str] = Field(None, description="Type of last financing (e.g. 'Secondary Transaction - Private')")
    last_financing_date: Optional[str] = Field(None, description="Date of last financing round")
    last_financing_size: Optional[str] = Field(None, description="Size of last financing round (e.g. '$14.58M')")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class DealHistoryEntry(BaseModel):
    deal_number: Optional[int] = Field(None, description="Deal sequence number")
    deal_date: Optional[str] = Field(None, description="Date of the deal (e.g. '27-Mar-2026')")
    deal_type: Optional[str] = Field(None, description="Type (e.g. 'Series I', 'PE Growth/Expansion')")
    deal_size: Optional[str] = Field(None, description="Deal size amount (e.g. '$6.50B')")
    pre_money_valuation: Optional[str] = Field(None, description="Pre-money valuation")
    post_money_valuation: Optional[str] = Field(None, description="Post-money valuation")
    deal_status: Optional[str] = Field(None, description="Status (e.g. 'Completed')")
    deal_stage: Optional[str] = Field(None, description="Stage (e.g. 'Later Stage VC', 'Startup')")
    lead_investors: list[str] = Field(default_factory=list, description="Lead investor names")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class InvestorEntry(BaseModel):
    investor_name: str = Field(description="Name of the investor firm or individual")
    investor_type: Optional[str] = Field(None, description="Type (e.g. 'Venture Capital', 'PE', 'Angel', 'Accelerator')")
    status: Optional[str] = Field(None, description="Status (e.g. 'New Investor', 'Existing Investor')")
    is_lead: Optional[bool] = Field(None, description="Whether this was a lead/sole investor")
    holding_since: Optional[str] = Field(None, description="Holding since date")
    related_deals: list[str] = Field(default_factory=list, description="Deal numbers or types participated in")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class KeyPerson(BaseModel):
    name: str = Field(description="Person's full name")
    title: Optional[str] = Field(None, description="Job title (e.g. 'CEO & Co-Founder')")
    role_type: Optional[str] = Field(None, description="'executive', 'board_member', or 'advisor'")
    location: Optional[str] = Field(None, description="Person's location if available")
    email: Optional[str] = Field(None, description="Email if available")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class Competitor(BaseModel):
    name: str = Field(description="Name of the competitor or similar company")
    financing_status: Optional[str] = Field(None, description="Competitor financing status")
    total_raised: Optional[str] = Field(None, description="Total raised by competitor")
    last_known_valuation: Optional[str] = Field(None, description="Last known valuation")
    hq_location: Optional[str] = Field(None, description="HQ location if available")
    industry: Optional[str] = Field(None, description="Primary industry or vertical")

class CompanySignals(BaseModel):
    vc_exit_predictor_score: Optional[str] = Field(None, description="Opportunity score (e.g. '79')")
    vc_exit_type: Optional[str] = Field(None, description="Predicted exit (e.g. 'Success - 98% Probability')")
    recent_news: list[str] = Field(default_factory=list, description="Recent news headlines")
    growth_indicators: list[str] = Field(default_factory=list, description="Growth signals or metrics")
    risk_signals: list[str] = Field(default_factory=list, description="Risk factors or concerns")
    comparable_public_companies: list[str] = Field(default_factory=list, description="Comparable public companies")
    competitors: list[Competitor] = Field(default_factory=list, description="Top similar companies and competitors")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class ServiceProvider(BaseModel):
    name: str = Field(description="Service provider name")
    service_type: Optional[str] = Field(None, description="Service type (e.g. 'Debt Financing', 'Legal')")
    hired_by: Optional[str] = Field(None, description="Who hired them")
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

# Generic Unknown Section fallback
class GenericSectionExtraction(BaseModel):
    key_insights: list[str] = Field(default_factory=list)
    entities_mentioned: list[str] = Field(default_factory=list)
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)

class ContentBlock(BaseModel):
    block_type: str  # "text" or "table"
    page: int
    content: Any  # string or list of dicts (table rows)
    section: str = "Unknown_Section"
    entities: list[dict] = Field(default_factory=list)

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 1 — Layout-aware Extraction + Table Deterministic Processing
# ══════════════════════════════════════════════════════════════════════════════

def extract_pdf_blocks(pdf_path: str) -> List[ContentBlock]:
    blocks = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages, 1):
            # Extract Tables first so we know where they are
            tables = page.find_tables()
            table_bboxes = [t.bbox for t in tables] if tables else []
            
            if tables:
                for table in tables:
                    table_rows = table.extract()
                    if table_rows:
                        # Convert table to deterministic structured rows
                        structured_rows = []
                        headers = None
                        for row in table_rows:
                            cleaned_row = [str(cell).replace("\n", " ").strip() if cell else "" for cell in row]
                            if not any(cleaned_row):
                                continue
                            if not headers:
                                headers = cleaned_row
                            else:
                                # Ensure zip length matches by padding cleaned_row if needed
                                if len(cleaned_row) < len(headers):
                                    cleaned_row.extend([""] * (len(headers) - len(cleaned_row)))
                                row_dict = dict(zip(headers, cleaned_row[:len(headers)]))
                                structured_rows.append(row_dict)
                        if structured_rows:
                            blocks.append(ContentBlock(block_type="table", page=i, content=structured_rows))
            
            # Extract Text, ignoring bounding boxes that overlap with tables
            def not_in_table(obj):
                for bbox in table_bboxes:
                    x0, top, x1, bottom = bbox
                    if (obj.get('x0', 0) >= x0 and obj.get('x1', 0) <= x1 and
                        obj.get('top', 0) >= top and obj.get('bottom', 0) <= bottom):
                        return False
                return True
            
            # Use extra_attrs to capture basic typography if needed for segmentation
            text_outside_tables = page.filter(not_in_table).extract_text()
            if text_outside_tables:
                for paragraph in text_outside_tables.split("\n\n"):
                    p = paragraph.strip()
                    if p:
                        blocks.append(ContentBlock(block_type="text", page=i, content=p))
                        
    return blocks

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 2 — Section Segmentation (Dynamic)
# ══════════════════════════════════════════════════════════════════════════════

SECTION_HEADERS_REGEX = re.compile(
    r"^(Highlights|General Information|Description|Most Recent Financing Status|"
    r"Industries, Verticals & Keywords|SIC Codes|NAICS Codes|Contact Information|"
    r"Financials|Key Metrics|Income Statement|Top 5 Similar Companies|"
    r"Comparison|Deal History|Financing History|Investors|Active Investors|"
    r"Advisors|Service Providers|Service on a Deal|Board Members & Advisors|"
    r"Key Team Members|Board Members|People|Recent News|Limited Partners|"
    r"Acquiree Profile|Acquisitions|Post-Acquisition Details|VC Exit Predictor|"
    r"Competition)\s*(?:\(\d+\))?$", re.IGNORECASE
)

def is_dynamic_header(text: str) -> bool:
    """Strictly use the regex to avoid false positives like page headers."""
    header_cand = text.strip()
    if not header_cand or len(header_cand) > 60: return False
    
    # Semantic: Headers rarely end with punctuation
    if header_cand.endswith(('.', ',', ';', ':')): return False
    
    return bool(SECTION_HEADERS_REGEX.match(header_cand))

def segment_into_sections(blocks: List[ContentBlock]) -> List[ContentBlock]:
    segmented_blocks = []
    current_section = "Preamble"
    
    for block in blocks:
        if block.block_type == "table":
            block.section = current_section
            segmented_blocks.append(block)
        elif block.block_type == "text":
            lines = block.content.split("\n")
            current_chunk = []
            
            for line in lines:
                line_stripped = line.strip()
                if is_dynamic_header(line_stripped):
                    # Save the previous chunk
                    if current_chunk:
                        chunk_text = "\n".join(current_chunk).strip()
                        if chunk_text:
                            segmented_blocks.append(ContentBlock(
                                block_type="text",
                                page=block.page,
                                content=chunk_text,
                                section=current_section
                            ))
                        current_chunk = []
                    
                    clean_header = re.sub(r"\s*\(\d+\)$", "", line_stripped)
                    current_section = clean_header
                    current_chunk.append(line)
                else:
                    current_chunk.append(line)
                    
            if current_chunk:
                chunk_text = "\n".join(current_chunk).strip()
                if chunk_text:
                    segmented_blocks.append(ContentBlock(
                        block_type="text",
                        page=block.page,
                        content=chunk_text,
                        section=current_section
                    ))
    
    return segmented_blocks

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 3 — Entity Boundary Detection (GLiNER)
# ══════════════════════════════════════════════════════════════════════════════

def detect_entities(blocks: List[ContentBlock]):
    model = get_gliner_model()
    if not model:
        log.warning("GLiNER not loaded. Skipping entity boundary detection.")
        return blocks
    
    labels = ["Person", "Organization", "Date", "Money", "Role", "Investment Round"]
    
    for block in blocks:
        if block.block_type == "text":
            try:
                # Predict entities
                entities = model.predict_entities(block.content, labels)
                block.entities = [{"text": e["text"], "label": e["label"]} for e in entities]
            except Exception as e:
                log.error(f"GLiNER error on text block: {e}")
        elif block.block_type == "table":
            flat_text = json.dumps(block.content)
            try:
                # Limit length for performance if table is massive
                entities = model.predict_entities(flat_text[:3000], labels)
                block.entities = [{"text": e["text"], "label": e["label"]} for e in entities]
            except Exception:
                pass
                
    return blocks

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 4 & 5 — Typed Micro-Chunking & Routing
# ══════════════════════════════════════════════════════════════════════════════

def build_chunk_groups(blocks: List[ContentBlock]) -> Dict[str, List[ContentBlock]]:
    groups = {
        "overview_and_info": [],
        "financials": [],
        "deal_history": [],
        "investors_and_advisors": [],
        "people": [],
        "signals_and_competition": [],
        "unknown_sections": []
    }
    
    def map_section(sec_name: str) -> str:
        s = sec_name.lower()
        if any(x in s for x in ["preamble", "highlights", "general information", "description", "industries", "contact", "status", "sic codes", "naics codes"]):
            return "overview_and_info"
        if any(x in s for x in ["financials", "metrics", "income"]):
            return "financials"
        if "deal" in s or "financing history" in s:
            return "deal_history"
        if any(x in s for x in ["investor", "advisor", "service provider", "limited partner"]):
            return "investors_and_advisors"
        if any(x in s for x in ["team", "board", "people"]):
            return "people"
        if any(x in s for x in ["news", "exit", "competit", "similar", "comparison", "acquis"]):
            return "signals_and_competition"
        return "unknown_sections"

    for block in blocks:
        group_key = map_section(block.section)
        groups[group_key].append(block)
        
    return groups

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 6 & 7 — Grounding, LLM Extraction, and Resolution
# ══════════════════════════════════════════════════════════════════════════════

CHUNK_PROMPTS = {
    "overview_and_info": {"schema": CompanyOverview, "is_list": False},
    "financials": {"schema": Financials, "is_list": False},
    "deal_history": {"schema": list[DealHistoryEntry], "is_list": True},
    "people": {"schema": list[KeyPerson], "is_list": True},
    "signals_and_competition": {"schema": CompanySignals, "is_list": False},
    "unknown_sections": {"schema": list[GenericSectionExtraction], "is_list": True}
}

class InvestorsAndAdvisorsResult(BaseModel):
    investors: list[InvestorEntry] = Field(default_factory=list)
    service_providers: list[ServiceProvider] = Field(default_factory=list)

def _get_gemini_client():
    from google import genai
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY not set in environment")
    return genai.Client(api_key=api_key)

def _call_gemini_api(client, target_company: str, blocks: List[ContentBlock], schema: Any, pdf_path: str = None) -> Any:
    # Grounding Instruction
    instruction = f"Extract structured data from the document blocks and the provided page images. ALL EXTRACTED DATA MUST BE EXCLUSIVELY ABOUT OR RELATED TO THE TARGET COMPANY: '{target_company}'. Do not mistakenly extract competitor data. Use the visual layout, typography, and headings from the images to ensure accurate section parsing. For tables, you are given deterministic JSON rows; clean them and map them to the schema."
    
    text_payload = []
    for b in blocks:
        block_rep = f"[Page {b.page} | Section: {b.section}]\n"
        if b.entities:
            ent_str = ", ".join([e["text"] for e in b.entities])
            block_rep += f"(Detected Entities: {ent_str})\n"
        if b.block_type == "table":
            block_rep += json.dumps(b.content, indent=2)
        else:
            block_rep += b.content
        text_payload.append(block_rep)
        
    prompt = f"{instruction}\n\nRAW BLOCKS:\n" + "\n\n".join(text_payload)
    
    images = []
    if pdf_path:
        try:
            doc = fitz.open(pdf_path)
            pages_to_extract = sorted(list(set(b.page for b in blocks)))
            for p_num in pages_to_extract:
                page = doc.load_page(p_num - 1)
                pix = page.get_pixmap(dpi=150)
                img_data = pix.tobytes("png")
                images.append(Image.open(io.BytesIO(img_data)))
            doc.close()
        except Exception as e:
            log.warning(f"Failed to load images from PDF: {e}")
    
    try:
        response = client.models.generate_content(
            model="gemini-2.5-pro",
            contents=[prompt] + images,
            config={
                "response_mime_type": "application/json",
                "response_schema": schema,
                "temperature": 0.1,
            },
        )
        
        if response.parsed:
            if isinstance(response.parsed, list):
                res = [item.model_dump() if hasattr(item, 'model_dump') else item for item in response.parsed]
            else:
                res = response.parsed.model_dump()
        else:
            res = json.loads(response.text)
            
        # Attach Provenance (Pages & Sections)
        pages = list(set([b.page for b in blocks]))
        sections = list(set([b.section for b in blocks]))
        prov = {"pages": pages, "sections": sections}
        
        if isinstance(res, list):
            for item in res:
                if isinstance(item, dict): item["provenance"] = prov
        elif isinstance(res, dict):
            if "investors" in res:
                for i in res["investors"]: i["provenance"] = prov
                for sp in res.get("service_providers", []): sp["provenance"] = prov
            else:
                res["provenance"] = prov
                
        return res
    except Exception as e:
        log.error(f"Gemini API Error: {e}")
        return [] if "list" in str(schema).lower() else {}

def process_group(client, group_name: str, blocks: List[ContentBlock], target_company: str, pdf_path: str = None) -> Any:
    if not blocks:
        return [] if CHUNK_PROMPTS.get(group_name, {}).get("is_list") else {}
        
    config = CHUNK_PROMPTS.get(group_name)
    if group_name == "investors_and_advisors":
        schema = InvestorsAndAdvisorsResult
    elif config:
        schema = config["schema"]
    else:
        return {}

    # Parallel micro-chunking based on block character size
    batches = []
    current_batch = []
    current_len = 0
    for b in blocks:
        l = len(str(b.content))
        if current_len + l > MICRO_CHUNK_SIZE_LIMIT and current_batch:
            batches.append(current_batch)
            current_batch = [b]
            current_len = l
        else:
            current_batch.append(b)
            current_len += l
    if current_batch:
        batches.append(current_batch)

    log.info(f"  → Processing {group_name} in {len(batches)} batch(es)...")
    
    all_results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_REQUESTS) as executor:
        futures = [executor.submit(_call_gemini_api, client, target_company, batch, schema, pdf_path) for batch in batches]
        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            if res:
                all_results.append(res)

    # Resolution / Merging
    def string_hash(d):
        # Hash without provenance to deduplicate correctly
        clean_d = {k: v for k, v in d.items() if k != "provenance"}
        return json.dumps(clean_d, sort_keys=True)

    if group_name == "investors_and_advisors":
        merged_inv, merged_sp = [], []
        for r in all_results:
            merged_inv.extend(r.get("investors", []))
            merged_sp.extend(r.get("service_providers", []))
        return {
            "investors": list({string_hash(i): i for i in merged_inv}.values()),
            "service_providers": list({string_hash(sp): sp for sp in merged_sp}.values())
        }
    elif config and config["is_list"]:
        merged = []
        for r in all_results:
            if isinstance(r, list): merged.extend(r)
        return list({string_hash(i): i for i in merged}.values())
    else:
        merged = {}
        for r in all_results:
            if isinstance(r, dict):
                for k, v in r.items():
                    if v is not None and v != [] and v != "":
                        merged[k] = v
        return merged

def extract_company_data(pdf_path: str) -> dict:
    company_name = Path(pdf_path).stem.replace("_profile", "").replace("_", " ")
    log.info(f"[Pipeline] Starting 7-Stage Extraction for: {company_name}")

    log.info("Stage 1 & 4: Layout-aware & Table Extraction")
    blocks = extract_pdf_blocks(pdf_path)
    
    log.info("Stage 2: Section Segmentation")
    blocks = segment_into_sections(blocks)
    
    log.info("Stage 3: Entity Boundary Detection")
    blocks = detect_entities(blocks)
    
    log.info("Stage 5: Typed Micro-Chunking Routing")
    groups = build_chunk_groups(blocks)

    client = _get_gemini_client()
    parsed_results = {}
    
    log.info("Stage 6 & 7: Target Grounding, LLM Extraction, and Resolution")
    for group_name, group_blocks in groups.items():
        result = process_group(client, group_name, group_blocks, company_name, pdf_path)
        parsed_results[group_name] = result

    inv_result = parsed_results.get("investors_and_advisors", {})

    data = {
        "company": company_name,
        "source_pdf": str(pdf_path),
        "overview": parsed_results.get("overview_and_info", {}),
        "financials": parsed_results.get("financials", {}),
        "deal_history": parsed_results.get("deal_history", []),
        "investors": list(inv_result.get("investors", []) if isinstance(inv_result, dict) else []),
        "key_people": parsed_results.get("people", []),
        "signals": parsed_results.get("signals_and_competition", {}),
        "service_providers": list(inv_result.get("service_providers", []) if isinstance(inv_result, dict) else []),
        "unknown_sections_preserved": parsed_results.get("unknown_sections", [])
    }

    log.info(f"[Pipeline] Extraction complete for {company_name}")
    return data

def save_company_data(data: dict, data_dir: str):
    Path(data_dir).mkdir(parents=True, exist_ok=True)
    filename = data["company"].replace(" ", "_") + "_data.json"
    output_path = os.path.join(data_dir, filename)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    log.info(f"Saved Canonical JSON: {output_path}")
    return output_path

def main():
    parser = argparse.ArgumentParser(description="Extract structured data from Pitchbook PDFs")
    parser.add_argument("--pdf", help="Path to a single PDF file")
    parser.add_argument("--all", action="store_true", help="Process all PDFs in output/pdfs/")
    parser.add_argument("--pdf-dir", default=PDF_DIR, help="Directory containing PDFs")
    parser.add_argument("--data-dir", default=DATA_DIR, help="Directory to save extracted JSON")
    args = parser.parse_args()

    if args.pdf:
        data = extract_company_data(args.pdf)
        save_company_data(data, args.data_dir)
    elif args.all:
        pdf_files = list(Path(args.pdf_dir).glob("*.pdf"))
        for pdf_path in pdf_files:
            try:
                data = extract_company_data(str(pdf_path))
                save_company_data(data, args.data_dir)
            except Exception as e:
                log.error(f"Failed to process {pdf_path}: {e}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()