"""
mcp_server.py
-------------
Official Anthropic Model Context Protocol (MCP) server for PitchBook automation.
Exposes tools via Server-Sent Events (SSE) and JSON-RPC.
"""

import os
import json
import logging
import argparse
import requests
import uvicorn
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.responses import JSONResponse
from starlette.requests import Request

from mcp.server import Server
from mcp.types import Tool, TextContent
from mcp.server.sse import SseServerTransport

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)

FASTAPI_URL = "http://127.0.0.1:8082"
# Set via environment variable or default to 'pitchbook-dev-key'
API_KEY = os.environ.get("MCP_API_KEY", "pitchbook-dev-key")

server = Server("pitchbook-agent")

@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    return [
        Tool(
            name="download_pitchbook_report",
            description="Downloads a PitchBook report for a company and extracts financial data.",
            inputSchema={
                "type": "object",
                "properties": {
                    "company_name": {
                        "type": "string",
                        "description": "Name of the company to search for"
                    },
                    "extract_data": {
                        "type": "boolean",
                        "description": "Whether to extract JSON data from the downloaded PDF",
                        "default": True
                    }
                },
                "required": ["company_name"]
            }
        ),
        Tool(
            name="download_batch",
            description="Downloads PitchBook reports for a list of companies.",
            inputSchema={
                "type": "object",
                "properties": {
                    "companies": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of company names"
                    },
                    "extract_data": {
                        "type": "boolean",
                        "description": "Whether to extract JSON data from the downloaded PDFs",
                        "default": True
                    }
                },
                "required": ["companies"]
            }
        ),
        Tool(
            name="get_status",
            description="Checks if the underlying PitchBook browser automation service is reachable.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        )
    ]

@server.call_tool()
async def handle_call_tool(name: str, arguments: dict) -> list[TextContent]:
    log.info(f"Tool called: {name} with arguments: {arguments}")
    if name == "get_status":
        try:
            requests.get(f"{FASTAPI_URL}/docs", timeout=2)
            agent_ok = True
        except Exception:
            agent_ok = False
        return [TextContent(type="text", text=json.dumps({
            "server": "running",
            "fastapi_agent_service": "reachable" if agent_ok else "unreachable"
        }))]

    elif name == "download_pitchbook_report":
        company_name = arguments.get("company_name")
        extract_data = arguments.get("extract_data", True)
        if not company_name:
            raise ValueError("company_name is required")
        try:
            resp = requests.post(
                f"{FASTAPI_URL}/api/download-pdf", 
                json={"company_name": company_name, "extract_data": extract_data}, 
                timeout=300
            )
            return [TextContent(type="text", text=json.dumps(resp.json()))]
        except Exception as e:
            return [TextContent(type="text", text=json.dumps({"error": str(e)}))]

    elif name == "download_batch":
        companies = arguments.get("companies", [])
        extract_data = arguments.get("extract_data", True)
        if not companies:
            raise ValueError("companies list is required")
        
        results = []
        for company in companies:
            try:
                payload = {"company_name": company, "extract_data": extract_data}
                resp = requests.post(f"{FASTAPI_URL}/api/download-pdf", json=payload, timeout=300)
                results.append({"company": company, "response": resp.json()})
            except Exception as e:
                results.append({"company": company, "error": str(e)})

        passed = sum(1 for r in results if r.get("response", {}).get("status") == "success")
        return [TextContent(type="text", text=json.dumps({
            "total": len(results),
            "success": passed,
            "failed": len(results) - passed,
            "results": results
        }))]
    
    raise ValueError(f"Unknown tool: {name}")

sse = SseServerTransport("/mcp/messages/")

def require_auth(request: Request):
    auth_header = request.headers.get("X-API-Key")
    if not auth_header or auth_header != API_KEY:
        log.warning(f"Unauthorized access attempt. Provided key: '{auth_header}'")
        raise ValueError("Unauthorized: Invalid X-API-Key")

async def handle_sse(request: Request):
    try:
        require_auth(request)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=401)
        
    async with sse.connect_sse(request.scope, request.receive, request._send) as streams:
        await server.run(streams[0], streams[1], server.create_initialization_options())

async def handle_messages(request: Request):
    try:
        require_auth(request)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=401)
        
    await sse.handle_post_message(request.scope, request.receive, request._send)

app = Starlette(routes=[
    Route("/mcp/sse", endpoint=handle_sse, methods=["GET"]),
    Route("/mcp/messages/", endpoint=handle_messages, methods=["POST"])
])

def main():
    parser = argparse.ArgumentParser(description="PitchBook MCP Server (SSE)")
    parser.add_argument("--port", type=int, default=8080, help="Port to listen on")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    args = parser.parse_args()

    log.info(f"Starting MCP SSE Server at http://{args.host}:{args.port}/mcp/sse")
    log.info(f"Requiring X-API-Key authentication (Default Key: {API_KEY})")
    
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")

if __name__ == "__main__":
    main()