import subprocess
import time
import os
import urllib.request
import sys


def start_persistent_browser():
    if sys.platform == "win32":
        chrome_exe = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
        if not os.path.exists(chrome_exe):
            chrome_exe = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    elif sys.platform == "darwin":
        chrome_exe = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    else:
        chrome_exe = "google-chrome"


    user_data_dir = os.path.join(os.getcwd(), "chrome_profile")
    os.makedirs(user_data_dir, exist_ok=True)

    print(f"Using profile: {user_data_dir}")
    print("Launching Chrome on port 9222...")

    proc = subprocess.Popen(
        [
            chrome_exe,
            "--remote-debugging-port=9222",
            "--remote-allow-origins=*",
            f"--user-data-dir={user_data_dir}",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-extensions",
            "--disable-dev-shm-usage",
            "--no-sandbox",
            "https://my.pitchbook.com/",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    time.sleep(3)

    for i in range(30):
        try:
            urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=2)
            print("✅ Chrome ready with CDP")
            break
        except Exception:
            time.sleep(1)
    else:
        print("❌ CDP not available")
        proc.terminate()
        return

    print("👉 Login manually in opened browser")

    try:
        proc.wait()
    except KeyboardInterrupt:
        print("Stopping browser...")
        proc.terminate()


if __name__ == "__main__":
    start_persistent_browser()
