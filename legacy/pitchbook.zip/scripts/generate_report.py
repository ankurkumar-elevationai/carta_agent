"""
Generate a 3-page technical implementation report as PDF.
"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from datetime import date
import os

OUTPUT_PATH = "./output/data/Pitchbook_Automation_Report.pdf"
os.makedirs("./output/data", exist_ok=True)

# ── Colour palette ──────────────────────────────────────────────────────────
NAVY   = colors.HexColor("#1B3A6B")
BLUE   = colors.HexColor("#2563EB")
LIGHT  = colors.HexColor("#EFF6FF")
GRAY   = colors.HexColor("#64748B")
RED    = colors.HexColor("#DC2626")
GREEN  = colors.HexColor("#16A34A")
WHITE  = colors.white
BLACK  = colors.HexColor("#111827")

# ── Styles ───────────────────────────────────────────────────────────────────
base = getSampleStyleSheet()

def sty(name, parent="Normal", **kw):
    s = ParagraphStyle(name, parent=base[parent], **kw)
    return s

TITLE   = sty("TITLE",   "Title",  fontSize=20, textColor=WHITE,
              alignment=TA_CENTER, spaceAfter=4, fontName="Helvetica-Bold")
SUB     = sty("SUB",     "Normal", fontSize=10, textColor=LIGHT,
              alignment=TA_CENTER, spaceAfter=2, fontName="Helvetica")
H1      = sty("H1",      "Normal", fontSize=13, textColor=NAVY,
              spaceBefore=10, spaceAfter=4, fontName="Helvetica-Bold")
H2      = sty("H2",      "Normal", fontSize=10, textColor=BLUE,
              spaceBefore=6,  spaceAfter=3, fontName="Helvetica-Bold")
BODY    = sty("BODY",    "Normal", fontSize=8.5, textColor=BLACK,
              leading=13, spaceAfter=3, alignment=TA_JUSTIFY)
BULLET  = sty("BULLET",  "Normal", fontSize=8.5, textColor=BLACK,
              leading=13, leftIndent=12, spaceAfter=2,
              bulletIndent=2, bulletFontName="Helvetica")
CODE    = sty("CODE",    "Normal", fontSize=7.5, textColor=NAVY,
              fontName="Courier", leading=11, leftIndent=12,
              backColor=LIGHT, spaceAfter=4)
CAPTION = sty("CAPTION", "Normal", fontSize=7.5, textColor=GRAY,
              alignment=TA_CENTER, spaceAfter=4)
FOOTER  = sty("FOOTER",  "Normal", fontSize=7,   textColor=GRAY,
              alignment=TA_CENTER)

def b(text):   return f"<b>{text}</b>"
def bl(text):  return Paragraph(f"• &nbsp; {text}", BULLET)
def code(text):return Paragraph(text, CODE)
def hr():      return HRFlowable(width="100%", thickness=0.5,
                                  color=colors.HexColor("#CBD5E1"),
                                  spaceAfter=6, spaceBefore=2)

# ── Table helper ─────────────────────────────────────────────────────────────
def make_table(data, col_widths, header=True):
    t = Table(data, colWidths=col_widths)
    style = [
        ("FONTNAME",    (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, -1), 8),
        ("BACKGROUND",  (0, 0), (-1, 0),  NAVY),
        ("TEXTCOLOR",   (0, 0), (-1, 0),  WHITE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT]),
        ("GRID",        (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")),
        ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",  (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING",(0,0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ]
    t.setStyle(TableStyle(style))
    return t

# ── Document ─────────────────────────────────────────────────────────────────
doc = SimpleDocTemplate(
    OUTPUT_PATH,
    pagesize=A4,
    leftMargin=1.8*cm, rightMargin=1.8*cm,
    topMargin=1.5*cm,  bottomMargin=1.8*cm,
)
W = A4[0] - 3.6*cm   # usable width

story = []

# ════════════════════════════════════════════════════════════════════════════
# HEADER BANNER (simulated with a coloured table)
# ════════════════════════════════════════════════════════════════════════════
banner_data = [[
    Paragraph("Pitchbook PDF Automation", TITLE),
]]
banner = Table(banner_data, colWidths=[W])
banner.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (-1,-1), NAVY),
    ("TOPPADDING",  (0,0), (-1,-1), 14),
    ("BOTTOMPADDING",(0,0),(-1,-1), 6),
    ("LEFTPADDING", (0,0), (-1,-1), 10),
]))
story.append(banner)

meta_data = [[
    Paragraph("Technical Implementation Report", SUB),
]]
meta = Table(meta_data, colWidths=[W])
meta.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (-1,-1), BLUE),
    ("TOPPADDING",  (0,0), (-1,-1), 4),
    ("BOTTOMPADDING",(0,0),(-1,-1), 6),
]))
story.append(meta)
story.append(Spacer(1, 10))

info_data = [
    ["Author", "Nikhil Kumar — Elevation AI"],
    ["Date",   date.today().strftime("%B %d, %Y")],
    ["Stack",  "Python 3.11 · Chrome CDP · ReportLab"],
    ["Status", "Production-ready"],
]
info_t = Table(info_data, colWidths=[2.5*cm, W - 2.5*cm])
info_t.setStyle(TableStyle([
    ("FONTNAME",     (0,0), (0,-1), "Helvetica-Bold"),
    ("FONTSIZE",     (0,0), (-1,-1), 8),
    ("TEXTCOLOR",    (0,0), (0,-1), NAVY),
    ("TEXTCOLOR",    (1,0), (1,-1), BLACK),
    ("TOPPADDING",   (0,0), (-1,-1), 3),
    ("BOTTOMPADDING",(0,0), (-1,-1), 3),
    ("LINEBELOW",    (0,-1),(-1,-1), 0.5, GRAY),
]))
story.append(info_t)
story.append(Spacer(1, 8))

# ════════════════════════════════════════════════════════════════════════════
# SECTION 1 — Project Overview
# ════════════════════════════════════════════════════════════════════════════
story.append(Paragraph("1. Project Overview", H1))
hr(); story.append(hr())
story.append(Paragraph(
    "This project automates the download of Pitchbook company PDF profiles for private "
    "market research at Elevation AI. Manually downloading profiles for 50+ companies "
    "takes a full workday. This script completes the same task in minutes without any "
    "human interaction, using Chrome DevTools Protocol (CDP) to control a real Chrome "
    "browser session.", BODY))

story.append(Paragraph("Key components:", H2))
comp_data = [
    ["Module", "File", "Purpose"],
    ["Main Automation",  "scripts/pitchbook_automation.py", "Login, search, download flow"],
    ["PDF Extraction",   "scripts/extract_pdf_data.py",     "Extract structured data from PDFs"],
    ["Excel Export",     "scripts/save_to_excel.py",        "Export data to multi-sheet Excel"],
    ["Company List",     "config/companies.json",           "Input: companies to process"],
    ["Settings",         "config/settings.json",            "Credentials and output paths"],
    ["Session Cookies",  "config/browser_cookies.json",     "Saved login session (~30 days)"],
]
story.append(make_table(comp_data, [3.2*cm, 6.5*cm, W-9.7*cm]))
story.append(Spacer(1, 6))

# ════════════════════════════════════════════════════════════════════════════
# SECTION 2 — Technical Implementation
# ════════════════════════════════════════════════════════════════════════════
story.append(Paragraph("2. Technical Implementation", H1))
story.append(hr())

story.append(Paragraph("2.1  Chrome Launch &amp; CDP Connection", H2))
story.append(bl("Checks port 18800 via <code>http://127.0.0.1:18800/json</code> — if Chrome is already running, it reuses the existing session."))
story.append(bl("If not running → launches Chrome with <b>--remote-debugging-port=18800</b> flag via <code>subprocess.Popen</code>."))
story.append(bl("Identifies the correct tab by filtering for <code>pitchbook.com</code> in the tab URL list."))
story.append(bl("All subsequent commands are JSON messages sent over a <b>WebSocket</b> to that tab."))

story.append(Paragraph("2.2  Session Management (Cookie-based Auth)", H2))
story.append(bl("After login, 40 session cookies are saved to <code>config/browser_cookies.json</code>."))
story.append(bl("On each run, cookies are injected via <b>Network.setCookies</b> CDP command — no password entry needed for ~30 days."))
story.append(bl("If cookies are expired, script falls back to credential login using the settings file."))

story.append(Paragraph("2.3  Company Search (isTrusted Events)", H2))
story.append(bl("Locates the search bar via <code>getBoundingClientRect()</code> polling (up to 20 s)."))
story.append(bl("Types via <b>Input.insertText</b> CDP command → generates <code>isTrusted: true</code> keyboard events that Pitchbook's search handler accepts."))
story.append(bl("Regular Selenium / JS <code>dispatchEvent</code> produces <code>isTrusted: false</code> events, which Pitchbook silently ignores."))
story.append(bl("Presses Enter via <b>Input.dispatchKeyEvent</b> → navigates to <code>/gs/all</code> (General Search results page)."))
story.append(bl("Filters result anchors to only <code>my.pitchbook.com</code> URLs to avoid clicking external links."))

story.append(Paragraph("2.4  Profile Load Detection", H2))
story.append(bl("Polls every 1 s (up to 90 s) for the <b>Share</b> button — the stable DOM anchor on every Pitchbook profile."))
story.append(bl("Once Share is found, the <b>... button = allBtns[shareIdx − 1]</b> in DOM order."))

story.append(Paragraph("2.5  Flyout Menu Navigation (Real Cursor Events)", H2))
story.append(bl("Waits an extra 2 s after profile load for React event handlers to finish attaching."))
story.append(bl("Clicks <b>...</b> via <b>Input.dispatchMouseEvent mousePressed + mouseReleased</b>. Retries up to 3× if dropdown does not appear."))
story.append(bl("Moves cursor to <b>Download</b> via <b>Input.dispatchMouseEvent mouseMoved</b> — this moves the real OS cursor, triggering CSS <code>:hover</code> which opens the flyout submenu."))
story.append(bl("JS <code>mouseover</code> / <code>element.dispatchEvent()</code> does NOT open the flyout — Pitchbook's submenu requires a real cursor movement."))
story.append(bl("Clicks <b>PDF</b> in the submenu via CDP mouse events."))

story.append(Paragraph("2.6  Confirmation Modal Handling", H2))
story.append(bl("After clicking PDF, Pitchbook renders a <i>Download Profile (PDF)</i> modal asynchronously."))
story.append(bl("Script polls every 0.5 s (up to 20 s) for a visible <code>&lt;button&gt;</code> with text 'Download' inside viewport bounds."))
story.append(bl("Viewport filter: <code>r.top ≥ 0 &amp;&amp; r.top ≤ vh &amp;&amp; r.left ≥ 0 &amp;&amp; r.left ≤ vw</code> — prevents matching hidden off-screen elements."))
story.append(bl("Clicks the blue Download button → Chrome's native file download begins."))

story.append(Paragraph("2.7  PDF Detection &amp; Save", H2))
story.append(bl("Records <code>started_at = time.time()</code> before triggering download."))
story.append(bl("Polls <code>~/Downloads</code> every 1 s (up to 180 s) for any <code>.pdf</code> with <code>mtime ≥ started_at</code>."))
story.append(bl("Copies file to <code>output/pdfs/CompanyName_profile.pdf</code> via <code>shutil.copy2()</code>."))
story.append(bl("Writes JSON run summary to <code>output/data/run_summary_&lt;timestamp&gt;.json</code>."))
story.append(Spacer(1, 4))

timeout_data = [
    ["Step", "Timeout / Retries"],
    ["Wait for profile ... button",    "90 seconds"],
    ["... button click retry",         "3 attempts × 2 s"],
    ["Confirmation popup poll",        "20 seconds (0.5 s interval)"],
    ["PDF appear in Downloads folder", "180 seconds"],
    ["Chrome CDP ready check",         "60 seconds"],
]
story.append(make_table(timeout_data, [9*cm, W-9*cm]))
story.append(Spacer(1, 8))

# ════════════════════════════════════════════════════════════════════════════
# SECTION 3 — Why OpenClaw Was Dropped
# ════════════════════════════════════════════════════════════════════════════
story.append(Paragraph("3. Why OpenClaw Was Dropped", H1))
story.append(hr())
story.append(Paragraph(
    "OpenClaw was the original plan — an AI agent platform that drives the browser via "
    "an MCP server. After proof-of-concept testing, it was fully replaced by direct CDP "
    "for three reasons:", BODY))

story.append(Paragraph("3.1  networkidle Timeout Crashes", H2))
story.append(Paragraph(
    "OpenClaw waits for the page network to go completely silent before acting. "
    "Pitchbook keeps continuous background API calls running (analytics, telemetry, "
    "session heartbeats), so networkidle <b>never fires</b>. The script would hang "
    "indefinitely and crash every single run.", BODY))

story.append(Paragraph("3.2  Orphan Node Processes", H2))
story.append(Paragraph(
    "Every crash left behind a zombie <code>node.exe</code> process. These accumulated "
    "over multiple runs, consuming memory and requiring manual Task Manager cleanup "
    "before the next run. There was no automatic cleanup mechanism.", BODY))

story.append(Paragraph("3.3  Unnecessary Complexity &amp; Cost", H2))
story.append(Paragraph(
    "OpenClaw added an AI agent layer, a REST gateway (must run as Administrator), "
    "and MCP server — all just to click three buttons in a browser. Each action also "
    "consumed API tokens. CDP achieves the same result in 50 lines of Python with "
    "no extra servers, no AI calls, and zero additional cost.", BODY))

story.append(Spacer(1, 4))
compare_data = [
    ["Criterion",              "OpenClaw (dropped)",   "CDP (current)"],
    ["Extra servers required", "Yes — gateway as Admin","No"],
    ["networkidle dependency", "Yes → crashes always",  "No"],
    ["isTrusted events",       "No (ignored by site)",  "Yes — native to CDP"],
    ["CSS hover / flyout menus","Unreliable",           "Works via mouseMoved"],
    ["Cost per run",           "API tokens consumed",   "Free"],
    ["Orphan processes",       "Yes — node.exe leaks",  "No"],
    ["Setup complexity",       "High",                  "Low"],
    ["Reliability",            "Low",                   "High"],
]
story.append(make_table(compare_data, [4.5*cm, 5.5*cm, W-10*cm]))
story.append(Spacer(1, 10))

story.append(Paragraph(
    "Pitchbook Automation Report  ·  Elevation AI  ·  Nikhil Kumar  ·  "
    f"{date.today().strftime('%B %d, %Y')}  ·  Confidential",
    FOOTER))

# ── Build ─────────────────────────────────────────────────────────────────────
doc.build(story)
print(f"Report saved -> {OUTPUT_PATH}")