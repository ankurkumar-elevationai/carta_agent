"""
save_to_excel.py
----------------
Reads extracted JSON data files from output/data/ and writes a structured
multi-sheet Excel report to output/reports/.

Sheets produced:
  - Summary        : one row per company, high-level overview + financials
  - Deal History   : all deals across all companies
  - Investors      : all investor profiles across all companies
  - Team           : key executives per company
  - Signals        : recent news / growth / risk signals

Usage:
    python scripts/save_to_excel.py
    python scripts/save_to_excel.py --data-dir output/data --reports-dir output/reports
"""

import os
import json
import argparse
import logging
from pathlib import Path
from datetime import datetime

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)

DATA_DIR = "./output/data"
REPORTS_DIR = "./output/reports"

# Brand colours (deep blue header, white text)
HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(color="FFFFFF", bold=True)


# ── Data loader ───────────────────────────────────────────────────────────────
def load_all_company_data(data_dir: str) -> list[dict]:
    json_files = list(Path(data_dir).glob("*_data.json"))
    if not json_files:
        log.warning(f"No JSON data files found in {data_dir}")
        return []
    companies = []
    for jf in json_files:
        with open(jf, "r") as f:
            companies.append(json.load(f))
    log.info(f"Loaded {len(companies)} company data files.")
    return companies


# ── Sheet builders ────────────────────────────────────────────────────────────
def build_summary_df(companies: list[dict]) -> pd.DataFrame:
    rows = []
    for c in companies:
        ov = c.get("overview", {})
        fi = c.get("financials", {})
        rows.append(
            {
                "Company": c.get("company"),
                "Industry": ov.get("industry"),
                "Founded Year": ov.get("founded_year"),
                "HQ Location": ov.get("hq_location"),
                "Employees": ov.get("employees"),
                "Website": ov.get("website"),
                "Total Funding Raised": fi.get("total_funding_raised"),
                "Revenue": fi.get("revenue"),
                "Valuation": fi.get("valuation"),
                "Post-Money Valuation": fi.get("post_money_valuation"),
                "Source PDF": c.get("source_pdf"),
            }
        )
    return pd.DataFrame(rows)


def build_deals_df(companies: list[dict]) -> pd.DataFrame:
    rows = []
    for c in companies:
        for deal in c.get("deal_history", []):
            rows.append(
                {
                    "Company": c.get("company"),
                    "Deal Date": deal.get("deal_date"),
                    "Deal Size": deal.get("deal_size"),
                    "Deal Type": deal.get("deal_type"),
                    "Lead Investors": deal.get("lead_investors"),
                }
            )
    return pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["Company", "Deal Date", "Deal Size", "Deal Type", "Lead Investors"]
    )


def build_investors_df(companies: list[dict]) -> pd.DataFrame:
    rows = []
    for c in companies:
        for inv in c.get("investor_profiles", []):
            rows.append(
                {
                    "Company": c.get("company"),
                    "Investor Name": inv.get("investor_name"),
                    "Status": inv.get("status"),
                    "Amount": inv.get("amount"),
                }
            )
    return pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["Company", "Investor Name", "Status", "Amount"]
    )


def build_team_df(companies: list[dict]) -> pd.DataFrame:
    rows = []
    for c in companies:
        team = c.get("team", {})
        rows.append(
            {
                "Company": c.get("company"),
                "CEO": team.get("ceo"),
                "CTO": team.get("cto"),
                "Board Members": ", ".join(team.get("board_members", [])),
                "Key Executives": ", ".join(team.get("key_executives", [])),
            }
        )
    return pd.DataFrame(rows)


def build_signals_df(companies: list[dict]) -> pd.DataFrame:
    rows = []
    for c in companies:
        signals = c.get("company_signals", {})
        rows.append(
            {
                "Company": c.get("company"),
                "Recent News": " | ".join(signals.get("recent_news", [])),
                "Growth Indicators": " | ".join(signals.get("growth_indicators", [])),
                "Risk Signals": " | ".join(signals.get("risk_signals", [])),
            }
        )
    return pd.DataFrame(rows)


# ── Excel styling ─────────────────────────────────────────────────────────────
def style_sheet(ws):
    """Apply header styling and auto-width to a worksheet."""
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for col in ws.columns:
        max_len = max((len(str(cell.value or "")) for cell in col), default=10)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max_len + 4, 50)

    ws.freeze_panes = "A2"


# ── Main export ───────────────────────────────────────────────────────────────
def export_to_excel(companies: list[dict], reports_dir: str) -> str:
    Path(reports_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = os.path.join(reports_dir, f"pitchbook_report_{timestamp}.xlsx")

    sheets = {
        "Summary": build_summary_df(companies),
        "Deal History": build_deals_df(companies),
        "Investors": build_investors_df(companies),
        "Team": build_team_df(companies),
        "Signals": build_signals_df(companies),
    }

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    # Apply styling with openpyxl
    wb = load_workbook(output_path)
    for sheet_name in sheets:
        style_sheet(wb[sheet_name])
    wb.save(output_path)

    log.info(f"Excel report saved: {output_path}")
    return output_path


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Export extracted Pitchbook data to Excel")
    parser.add_argument("--data-dir", default=DATA_DIR, help="Directory with extracted JSON files")
    parser.add_argument("--reports-dir", default=REPORTS_DIR, help="Directory to save Excel report")
    args = parser.parse_args()

    companies = load_all_company_data(args.data_dir)
    if not companies:
        log.error("No data to export. Run extract_pdf_data.py first.")
        return

    output_path = export_to_excel(companies, args.reports_dir)
    print(f"\nReport ready: {output_path}")


if __name__ == "__main__":
    main()