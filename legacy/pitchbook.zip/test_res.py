import asyncio
from pitchbook_client import PitchBookMCPClient
async def test():
    client = PitchBookMCPClient("http://35.208.71.71:8080")
    await client.initialize_session()
    result = await client.download_report("OpenAI")
    print(result)  # ← You will see the full JSON here
    await client.close()
asyncio.run(test())