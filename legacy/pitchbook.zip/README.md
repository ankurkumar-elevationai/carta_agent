# OpenClaw + Pitchbook Automation

Automated company research and PDF download system for Pitchbook via OpenClaw AI agent.

**Author:** Nikhil Kumar | **Team:** Elevation AI | **Status:** In Progress

---

## What This Does

1. Logs into Pitchbook automatically
2. Searches for each company in your list
3. Downloads the full company PDF report
4. Extracts structured data from each PDF
5. Exports everything into a multi-sheet Excel report

---

## Prerequisites

| Requirement | Version |
|---|---|
| Anaconda | Latest |
| Python | 3.11+ |
| OpenClaw | v2026.4.2 |
| Node.js | 18+ |
| Chrome | Latest |

---

## Setup (One-Time)

### Step 1 — Create Anaconda Environment

Open **Anaconda Prompt** and run:

```bash
conda create -n pitchbook-env python=3.11
conda activate pitchbook-env
```

### Step 2 — Install OpenClaw (as Administrator)

Open **PowerShell as Administrator** (NOT VSCode terminal) and run:

```powershell
iwr -useb https://openclaw.ai/install.ps1 | iex
```

### Step 3 — Install Python Libraries

In VSCode terminal (with pitchbook-env active):

```bash
pip install requests websocket-client pdfplumber pandas openpyxl playwright
playwright install chromium
```

### Step 4 — Configure Credentials

Edit `config/settings.json` and fill in:

```json
{
  "openclaw": {
    "token": "YOUR_OPENCLAW_TOKEN_HERE"
  },
  "pitchbook": {
    "email": "your-email@elevationai.com",
    "password": "your-pitchbook-password"
  }
}
```

### Step 5 — Add Your Company List

Edit `config/companies.json`:

```json
{
  "companies": ["Wingify", "CarDekho", "Lenskart", "OfBusiness"]
}
```

---

## Running the Automation

### Step 1 — Start OpenClaw Gateway (OUTSIDE VSCode, as Admin)

Open **PowerShell as Administrator** and run:

```powershell
node "C:\Users\nikhil kumar\AppData\Roaming\npm\node_modules\openclaw\dist\index.js" gateway --port 18789
```

Wait until you see:
```
gateway listening on ws://127.0.0.1:18789
Browser control listening on http://127.0.0.1:18791
```

Keep this window open.

### Step 2 — Download PDFs

In VSCode terminal:

```bash
python scripts/pitchbook_automation.py
```

To run with specific companies:

```bash
python scripts/pitchbook_automation.py --companies "Wingify" "CarDekho"
```

### Step 3 — Extract Data from PDFs

```bash
python scripts/extract_pdf_data.py --all
```

### Step 4 — Export to Excel

```bash
python scripts/save_to_excel.py
```

Find your report in `output/reports/pitchbook_report_<timestamp>.xlsx`

---

## MCP Server (Future / API Mode)

Start the REST API server:

```bash
python scripts/mcp_server.py --port 8080
```

Then trigger downloads via HTTP:

```bash
# Download a single company PDF
curl -X POST http://127.0.0.1:8080/api/download-pdf \
  -H "Content-Type: application/json" \
  -d '{"company_name": "Wingify", "extract_data": true}'

# Download a batch
curl -X POST http://127.0.0.1:8080/api/download-batch \
  -H "Content-Type: application/json" \
  -d '{"companies": ["Wingify", "CarDekho", "Lenskart"]}'

# Check status
curl http://127.0.0.1:8080/api/status
```

---

## Folder Structure

```
openclaw_pitchbook/
├── PRD/                          # Product Requirements Document
├── scripts/
│   ├── pitchbook_automation.py   # Main: login + download PDFs
│   ├── extract_pdf_data.py       # Extract structured data from PDFs
│   ├── save_to_excel.py          # Export data to Excel report
│   └── mcp_server.py             # REST API server
├── output/
│   ├── pdfs/                     # Downloaded Pitchbook PDFs
│   ├── data/                     # Extracted JSON data per company
│   └── reports/                  # Final Excel reports
├── config/
│   ├── companies.json            # List of companies to process
│   └── settings.json            # API keys and credentials (DO NOT COMMIT)
└── README.md
```

---

## Known Issues & Workarounds

| Issue | Workaround |
|---|---|
| Gateway crashes on Windows | Use direct Node.js command (not `openclaw start`) |
| MFA/OTP required on each login | Pre-authenticate and save browser cookies |
| Pitchbook session expires | Store session cookies; re-use across runs |
| Browser click timeouts | Delays already added between steps |
| Gemini API timeouts | Switch to Claude model in OpenClaw settings |
| Chrome DevTools port conflict | Use a dedicated OpenClaw browser profile |

---

## Success Targets

| Metric | Target |
|---|---|
| PDF Download Success Rate | 90%+ |
| Time per Company | < 2 minutes |
| Session Stability | 1 hour without crash |
| MFA Handling | Fully automated |
| Companies per Run | 50+ |

---

## Contact

- **Nikhil Kumar** — project lead
- **Saumya Garg** — stakeholder
- **Hanzel Corella** — provides company lists
- **Alan Abraham** — stakeholder