import os
import asyncio
import urllib.request
import logging
from playwright.async_api import async_playwright

log = logging.getLogger(__name__)


class PitchbookAgent:
    async def run(self, company_name: str) -> dict:
        """
        Executes the Pitchbook PDF download process using Playwright.
        Connects to a persistent Chrome instance via CDP on port 9222.
        Returns a dict containing 'status' and 'file_path' or 'error'.
        """
        try:
            log.info("Checking for persistent Chrome on port 9222...")
            try:
                urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=2)
                log.info("Successfully reached Chrome debug port.")
            except Exception:
                raise Exception("Could not connect to Chrome debug port. Make sure to run 'python scripts/start_persistent_browser.py' first.")

            async with async_playwright() as p:
                log.info("Connecting to Chrome via CDP...")
                browser = await p.chromium.connect_over_cdp("http://127.0.0.1:9222")
                log.info("Connected to Chrome!")

                context = browser.contexts[0]
                pages = context.pages

                # Find PitchBook page or create one
                page = None
                for pg in pages:
                    if "pitchbook" in pg.url.lower():
                        page = pg
                        break
                if not page:
                    page = pages[0] if pages else await context.new_page()
                
                # ALWAYS navigate to dashboard to reset state (clears modals/popups)
                log.info("Navigating to PitchBook dashboard...")
                await page.goto("https://my.pitchbook.com/", wait_until="domcontentloaded", timeout=30000)

                page.set_default_timeout(30000)

                # Retry logic for navigation
                max_retries = 3
                for attempt in range(max_retries):
                    try:
                        log.info(f"Waiting for PitchBook to load... (Attempt {attempt+1}/{max_retries})")
                        # Wait for either the search bar (logged in) or a login/submit button (logged out / SSO redirect)
                        await page.wait_for_selector("input[placeholder*='Search'], button[type='submit'], button:text-is('Log In'), button:text-is('Sign In'), button:text-is('Next'), button:text-is('Continue')", timeout=30000)
                        break
                    except Exception as e:
                        if attempt == max_retries - 1:
                            raise Exception(f"PitchBook failed to load after {max_retries} attempts: {e}")
                        log.warning(f"Page not ready, retrying... ({e})")
                        await page.reload(wait_until="domcontentloaded", timeout=30000)
                        await asyncio.sleep(2)

                # Validate login and attempt auto-login if needed
                has_search = await page.locator("input[placeholder*='Search']").count() > 0
                has_idle_modal = await page.locator("text='Log back in'").count() > 0
                
                if has_idle_modal:
                    log.warning("PitchBook idle timeout detected. Clicking 'Log back in'...")
                    try:
                        await page.locator("text='Log back in'").first.click()
                        await page.wait_for_selector("input[placeholder*='Search']", timeout=15000)
                        has_search = True
                    except Exception:
                        pass
                
                if not has_search:
                    log.warning("Not logged in. Attempting auto-login using saved Chrome credentials...")
                    
                    # PitchBook/Morningstar login is often multi-step (Next -> Log In)
                    for step in range(2):
                        # Use text-is for exact match to avoid clicking "Sign in with SSO"
                        login_btn = page.locator("button[type='submit'], button:text-is('Log In'), button:text-is('Sign In'), button:text-is('Next'), button:text-is('Continue')").first
                        if await login_btn.count() > 0:
                            try:
                                # Click on an input field to trigger Chrome's password auto-fill securely
                                inputs = page.locator("input")
                                if await inputs.count() > 0:
                                    await inputs.first.click(timeout=2000)
                                    await asyncio.sleep(1)
                                
                                await login_btn.click(timeout=5000)
                                log.info(f"Clicked login button (Step {step+1}). Waiting...")
                                await asyncio.sleep(4)  # Wait for redirect or next step to render
                                
                                # If search bar appears immediately, break early
                                if await page.locator("input[placeholder*='Search']").count() > 0:
                                    break
                            except Exception as e:
                                log.warning(f"Could not click login button: {e}")
                                break
                        else:
                            break
                            
                    try:
                        await page.wait_for_selector("input[placeholder*='Search']", timeout=15000)
                        has_search = True
                        log.info("Auto-login successful!")
                    except Exception:
                        pass
                            
                if not has_search:
                    raise Exception("Session expired, invalid, or MFA required. Please log in manually on the persistent browser window.")

                log.info("Successfully authenticated via Chrome profile!")

                # Search company
                log.info(f"Searching for company: {company_name}")
                await page.fill("input[placeholder*='Search']", company_name)
                # Wait a split second for dropdown results to populate
                await asyncio.sleep(2)
                await page.keyboard.press("Enter")

                # PitchBook navigates from dashboard to /gs/all (search results).
                # This can invalidate the CDP page reference, so we wait for
                # navigation and then re-acquire the active page from the context.
                await asyncio.sleep(3)

                # Re-acquire the page — pick the one showing search results
                page = None
                for pg in context.pages:
                    if "pitchbook" in pg.url.lower():
                        page = pg
                        break
                if not page:
                    page = context.pages[-1]

                page.set_default_timeout(30000)

                # Wait for search results to render or direct profile load
                log.info("Waiting for search results or profile page to load...")
                await page.wait_for_selector(
                    'button[class*="gs-card-header"], button[data-testid="action-buttons"]',
                    state="visible",
                    timeout=25000
                )
                await asyncio.sleep(1)  # Brief extra delay for rendering

                is_direct_profile = await page.locator('button[data-testid="action-buttons"]').count() > 0
                clicked = False

                if not is_direct_profile:
                    # Click the target company in search results
                    log.info("Attempting to click company result...")
                    clicked = await page.evaluate("""
                        (name) => {
                            const buttons = document.querySelectorAll(
                                'button[class*="gs-card-header__flat-button"]'
                            );
                            for (const btn of buttons) {
                                if (btn.innerText.trim().toLowerCase() === name.toLowerCase()) {
                                    btn.click();
                                    return true;
                                }
                            }
                            return false;
                        }
                    """, company_name)

                    if not clicked:
                        log.warning(f"Could not find '{company_name}' button in search results. Trying text selector...")
                        try:
                            await page.locator(f"text={company_name}").first.click(timeout=10000)
                        except Exception:
                            log.warning(f"Could not click '{company_name}'. PitchBook may have auto-navigated.")
                else:
                    log.info("Auto-navigated directly to profile page!")

                # Clicking the company navigates to the profile page.
                # Re-acquire the page reference in case CDP invalidated it.
                await asyncio.sleep(3)
                page = None
                for pg in context.pages:
                    if "pitchbook" in pg.url.lower() and "profile" in pg.url.lower():
                        page = pg
                        break
                if not page:
                    # Fallback: use whichever PitchBook page is available
                    for pg in context.pages:
                        if "pitchbook" in pg.url.lower():
                            page = pg
                            break
                if not page:
                    page = context.pages[-1]

                page.set_default_timeout(30000)

                # Wait for the profile page to fully load
                # The action-buttons ('...') button only exists on profile pages
                log.info("Waiting for profile page to load...")
                await page.wait_for_selector(
                    'button[data-testid="action-buttons"]',
                    state="visible",
                    timeout=30000
                )
                log.info(f"Profile page loaded: {page.url}")

                # Open download menu
                log.info("Opening download menu ('...' button)...")

                # Scroll to top to ensure the header toolbar is visible
                await page.evaluate("window.scrollTo(0, 0)")
                await asyncio.sleep(1)

                # Using the exact data-testid from PitchBook's HTML
                # Retry the menu click up to 3 times (PitchBook menus can be flaky)
                menu_popup = None
                for menu_attempt in range(3):
                    menu_btn = page.locator('button[data-testid="action-buttons"]').first
                    await menu_btn.scroll_into_view_if_needed()
                    await asyncio.sleep(0.5)
                    await menu_btn.click()

                    # Wait for the action menu popup to appear
                    await asyncio.sleep(2)
                    try:
                        popup = page.locator('[role="menu"]').first
                        await popup.wait_for(state="visible", timeout=15000)
                        menu_popup = popup
                        break
                    except Exception:
                        log.warning(f"Menu did not open (attempt {menu_attempt+1}/3). Retrying...")
                        await asyncio.sleep(1)

                if not menu_popup:
                    raise Exception("Failed to open download menu after 3 attempts.")

                # Hover "Download" scoped to the popup menu (avoids hitting
                # other "Download" elements elsewhere on the profile page)
                log.info("Hovering 'Download' option in action menu...")
                await menu_popup.locator("text=Download").hover()

                # Wait for the PDF/Word/Excel flyout submenu to appear
                await asyncio.sleep(1)

                # Click "PDF" in the submenu — this opens a section-selection modal
                log.info("Clicking 'PDF' in download submenu...")
                await page.locator('[role="menu"]').last.locator("text=PDF").click()

                # Wait for the "Download Profile (PDF)" modal to appear
                log.info("Waiting for PDF section-selection modal...")
                modal = page.locator('.modal').filter(has_text="Download Profile")
                await modal.wait_for(state="visible", timeout=10000)

                # Click the "Download" button inside the modal footer to
                # trigger the actual PDF generation and download
                log.info("Clicking 'Download' in modal to trigger PDF export...")
                modal_dl_btn = modal.locator('.modal__footer button.button_primary').first

                async with page.expect_download(timeout=120000) as download_info:
                    await modal_dl_btn.click()

                download = await download_info.value

                # Save to output/pdfs/ in the project root
                safe_name = company_name.replace(' ', '_')
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                pdf_dir = os.path.join(project_root, "output", "pdfs")
                os.makedirs(pdf_dir, exist_ok=True)
                local_path = os.path.join(pdf_dir, f"{safe_name}.pdf")

                await download.save_as(local_path)

                log.info(f"Download complete: {local_path}")

                # Close the CDP connection (does NOT close the persistent Chrome)
                await browser.close()
                return {
                    "status": "success",
                    "file_path": local_path
                }

        except Exception as e:
            log.error(f"Error processing {company_name}: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
