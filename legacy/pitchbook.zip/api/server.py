import os
import sys
import asyncio
import logging
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

# Ensure we can import modules from the project root
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from services.pitchbook_agent import PitchbookAgent
from utils.gcs import upload_file
from scripts.extract_pdf_data import extract_company_data

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

app = FastAPI(title="PitchBook Agent API")

class DownloadRequest(BaseModel):
    company_name: str
    extract_data: bool = False

@app.post("/api/download-pdf")
async def download_pdf(req: DownloadRequest):
    agent = PitchbookAgent()
    log.info(f"Received request for company: {req.company_name}")
    
    result = await agent.run(req.company_name)
    
    if result.get("status") == "error":
        raise HTTPException(status_code=500, detail=result.get("error"))
        
    local_path = result.get("file_path")
    if not local_path or not os.path.exists(local_path):
        raise HTTPException(status_code=500, detail="PDF downloaded but file not found on disk")
        
    # Upload to GCS
    gcs_dest = f"pitchbook-pdfs/{os.path.basename(local_path)}"
    try:
        gcs_url = upload_file(local_path, gcs_dest)
    except Exception as e:
        log.error(f"Failed to upload to GCS: {e}")
        gcs_url = None
        
    data = {}
    if req.extract_data:
        try:
            log.info(f"Extracting data from {local_path}...")
            # extract_company_data from scripts/extract_pdf_data.py
            data = extract_company_data(local_path)
        except Exception as e:
            log.error(f"Data extraction failed: {e}")
            data = {"error": str(e)}
            
    # PDFs are saved to output/pdfs/ — keep them for verification
    # To auto-cleanup, uncomment below:
    # try:
    #     os.remove(local_path)
    # except OSError:
    #     pass

    return {
        "status": "success",
        "pdf_url": gcs_url,
        "data": data
    }

if __name__ == "__main__":
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    uvicorn.run("api.server:app", host="127.0.0.1", port=8082)
