import sys
sys.path.append('.')
from scripts.extract_pdf_data import extract_pdf_blocks, segment_into_sections

blocks = extract_pdf_blocks('./output/pdfs/adobe.pdf')
blocks = segment_into_sections(blocks)

for b in blocks:
    content_preview = b.content[:50].replace('\n', ' ') if b.block_type == 'text' else str(b.content)[:50]
    print(f"[{b.section}] {b.block_type} (Pg {b.page}): {content_preview}")
